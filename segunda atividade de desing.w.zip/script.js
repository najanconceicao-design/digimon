// ===== Configuração =====
const API_URL = "https://digi-api.com/api/v1/digimon";

// ===== Elementos da página =====
const formNome = document.getElementById("form-nome");
const formId = document.getElementById("form-id");
const campoNome = document.getElementById("campo-nome");
const campoId = document.getElementById("campo-id");
const status = document.getElementById("status");
const cartao = document.getElementById("cartao");
const btnAnterior = document.getElementById("btn-anterior");
const btnProximo = document.getElementById("btn-proximo");

const el = {
  img: document.getElementById("cartao-img"),
  id: document.getElementById("cartao-id"),
  nome: document.getElementById("cartao-nome"),
  nivel: document.getElementById("cartao-nivel"),
  tipo: document.getElementById("cartao-tipo"),
  atributo: document.getElementById("cartao-atributo"),
  areas: document.getElementById("cartao-areas"),
  habilidades: document.getElementById("cartao-habilidades"),
  descricao: document.getElementById("cartao-descricao"),
};

// Guarda o ID do Digimon na tela e o número da última busca
let idAtual = null;
let numeroBusca = 0;

// ===== Mensagens =====
function mostrarStatus(texto, ehErro = false) {
  status.textContent = texto;
  status.classList.toggle("erro", ehErro);
}

// ===== Limpar o cartão (evita dados antigos na tela) =====
function limparCartao() {
  el.img.hidden = true;
  el.img.removeAttribute("src");
  el.img.alt = "";
  el.id.textContent = "—";
  el.nome.textContent = "Nenhum Digimon na tela";
  el.nivel.textContent = "—";
  el.tipo.textContent = "—";
  el.atributo.textContent = "—";
  el.areas.textContent = "—";
  el.habilidades.textContent = "—";
  el.descricao.textContent = "Faça uma busca para ver os dados aqui.";
  cartao.classList.add("vazio");
  btnAnterior.disabled = true;
  btnProximo.disabled = true;
  idAtual = null;
}

// ===== Funções de apoio para ler a resposta =====
// Junta uma lista de objetos em texto. Ex.: levels -> "Rookie"
function juntar(lista, campo) {
  if (!Array.isArray(lista) || lista.length === 0) return "—";
  const textos = lista.map((item) => item[campo]).filter(Boolean);
  return textos.length ? textos.join(", ") : "—";
}

// Escolhe uma descrição em inglês (se existir) ou a primeira disponível
function escolherDescricao(descricoes) {
  if (!Array.isArray(descricoes) || descricoes.length === 0) {
    return "Sem descrição disponível.";
  }
  const ingles = descricoes.find((d) => (d.language || "").startsWith("en"));
  return (ingles || descricoes[0]).description || "Sem descrição disponível.";
}

// ===== Atualização dinâmica do cartão =====
function preencherCartao(d) {
  el.id.textContent = d.id;
  el.nome.textContent = d.name;
  el.nivel.textContent = juntar(d.levels, "level");
  el.tipo.textContent = juntar(d.types, "type");
  el.atributo.textContent = juntar(d.attributes, "attribute");
  el.areas.textContent = juntar(d.fields, "field");
  el.habilidades.textContent = juntar((d.skills || []).slice(0, 5), "skill");
  el.descricao.textContent = escolherDescricao(d.descriptions);

  const imagem = Array.isArray(d.images) && d.images[0] ? d.images[0].href : null;
  if (imagem) {
    el.img.src = imagem;
    el.img.alt = "Imagem de " + d.name;
    el.img.hidden = false;
  } else {
    el.img.hidden = true;
  }

  cartao.classList.remove("vazio");
  idAtual = d.id;
  btnAnterior.disabled = idAtual <= 1;
  btnProximo.disabled = false;
}

// ===== Requisições =====
async function pedirJson(url) {
  const resposta = await fetch(url);
  if (resposta.status === 404) return null; // não encontrado
  if (!resposta.ok) throw new Error("Erro HTTP " + resposta.status);
  return resposta.json();
}

// Busca pelo ID (endpoint /digimon/{id})
function buscarDetalhesPorId(id) {
  return pedirJson(API_URL + "/" + encodeURIComponent(id));
}

// Busca pelo nome: usa a lista (?name=) e depois pega os detalhes pelo ID
async function buscarDetalhesPorNome(nome) {
  const lista = await pedirJson(API_URL + "?name=" + encodeURIComponent(nome));
  const itens = lista && Array.isArray(lista.content) ? lista.content : [];
  if (itens.length === 0) return null;

  // Prefere o nome idêntico (sem diferenciar maiúsculas); senão, o primeiro
  const igual = itens.find((i) => i.name.toLowerCase() === nome.toLowerCase());
  return buscarDetalhesPorId((igual || itens[0]).id);
}

// ===== Fluxo comum às duas buscas =====
async function executarBusca(funcaoBusca, mensagemNaoEncontrado) {
  const minhaBusca = ++numeroBusca;
  limparCartao();
  mostrarStatus("Carregando...");

  try {
    const dados = await funcaoBusca();

    // Se o usuário fez outra busca enquanto esta carregava, ignora esta
    if (minhaBusca !== numeroBusca) return;

    if (!dados) {
      mostrarStatus(mensagemNaoEncontrado, true);
      return;
    }
    preencherCartao(dados);
    mostrarStatus("");
  } catch (erro) {
    if (minhaBusca !== numeroBusca) return;
    mostrarStatus("Não foi possível consultar a API. Verifique sua conexão e tente de novo.", true);
    console.error(erro);
  }
}

// ===== Eventos =====
formNome.addEventListener("submit", (evento) => {
  evento.preventDefault();
  const nome = campoNome.value.trim().replace(/\s+/g, " ");
  if (nome === "") {
    limparCartao();
    mostrarStatus("Digite um nome para buscar.", true);
    return;
  }
  executarBusca(
    () => buscarDetalhesPorNome(nome),
    'Nenhum Digimon encontrado com o nome "' + nome + '".'
  );
});

formId.addEventListener("submit", (evento) => {
  evento.preventDefault();
  const texto = campoId.value.trim();
  const id = Number(texto);
  if (texto === "" || !Number.isInteger(id) || id < 1) {
    limparCartao();
    mostrarStatus("Digite um ID válido (número inteiro maior que zero).", true);
    return;
  }
  executarBusca(
    () => buscarDetalhesPorId(id),
    "Nenhum Digimon encontrado com o ID " + id + "."
  );
});

btnAnterior.addEventListener("click", () => {
  if (idAtual === null || idAtual <= 1) return;
  const id = idAtual - 1;
  executarBusca(() => buscarDetalhesPorId(id), "Não há Digimon com o ID " + id + ".");
});

btnProximo.addEventListener("click", () => {
  if (idAtual === null) return;
  const id = idAtual + 1;
  executarBusca(() => buscarDetalhesPorId(id), "Não há Digimon com o ID " + id + ".");
});
