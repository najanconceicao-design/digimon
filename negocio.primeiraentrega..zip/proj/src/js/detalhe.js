// ===== Página de detalhe: cartão do Digimon + Anterior/Próximo =====
const cartao = document.getElementById("cartao");
const btnAnterior = document.getElementById("btn-anterior");
const btnProximo = document.getElementById("btn-proximo");
const posicao = document.getElementById("posicao");

// Descobre qual Digimon abrir pelo parâmetro ?id= da URL
const idDaUrl = Number(new URLSearchParams(location.search).get("id"));
let indiceAtual = Math.max(0, DIGIMONS.findIndex((d) => d.id === idDaUrl));

// Linha "rótulo: valor" (Tipo, Nível, Áreas)
function criarInfo(rotulo, valor) {
  const bloco = criar("div", "info");
  bloco.append(criar("span", "info__rotulo", rotulo), criar("span", "info__valor", valor));
  return bloco;
}

function mostrarDigimon(indice) {
  const d = DIGIMONS[indice];
  cartao.replaceChildren();

  const cabecalho = criar("header", "cartao__topo");
  cabecalho.append(criar("h2", "cartao__nome", d.name), criar("span", "cartao__id", formatarId(d.id)));

  const descricao = criar("section", "cartao__descricao");
  descricao.append(criar("h3", "", "Descrição"), criar("p", "", d.description));

  const dados = criar("section", "cartao__dados");
  dados.append(
    criarInfo("Tipo", d.type),
    criarInfo("Nível", d.level),
    criarInfo("Áreas", d.fields.join(", "))
  );

  const habilidades = criar("section", "habilidades");
  habilidades.append(criar("h3", "", "Habilidades"));
  d.skills.forEach((h) => {
    const item = criar("div", "habilidade");
    item.append(criar("h4", "habilidade__nome", h.name), criar("p", "habilidade__desc", h.description));
    habilidades.append(item);
  });

  cartao.append(cabecalho, criarImagem(d, "cartao__imagem"), descricao, dados, habilidades);
  posicao.textContent = `${indice + 1} / ${DIGIMONS.length}`;
  document.title = d.name + " - Digidex";
  indiceAtual = indice;

  // Mantém o ?id= da URL em dia (sem recarregar a página)
  try { history.replaceState(null, "", "?id=" + d.id); } catch (e) { /* ignora em file:// */ }
}

function proximo() { mostrarDigimon((indiceAtual + 1) % DIGIMONS.length); }
function anterior() { mostrarDigimon((indiceAtual - 1 + DIGIMONS.length) % DIGIMONS.length); }

btnProximo.addEventListener("click", proximo);
btnAnterior.addEventListener("click", anterior);
document.addEventListener("keydown", (e) => {
  if (e.key === "ArrowRight") proximo();
  if (e.key === "ArrowLeft") anterior();
});

mostrarDigimon(indiceAtual);