// Dados locais usados na Unidade 1.
// A estrutura imita a resposta da https://digi-api.com/ para facilitar
// a troca por fetch() na Unidade 2.
// Os IDs aqui são locais (sequenciais) e as descrições estão em português.
const IMG = (nome) => `https://digi-api.com/images/digimon/w/${nome}.png`;

const DIGIMONS = [
  {
    id: 1, name: "Koromon", image: IMG("Koromon"),
    description: "Forma de treinamento de Agumon. É alegre, curioso e adora pular por aí, mas ainda é frágil.",
    type: "Free", fields: ["Nature Spirits", "Virus Busters"], level: "In Training II",
    skills: [
      { name: "Bubble Blow", description: "Dispara bolhas de ar contra o oponente." }
    ]
  },
  {
    id: 2, name: "Agumon", image: IMG("Agumon"),
    description: "Um Digimon réptil corajoso e leal. É conhecido por seu apetite e pela coragem ao proteger os amigos.",
    type: "Reptile", fields: ["Nature Spirits", "Virus Busters"], level: "Rookie",
    skills: [
      { name: "Pepper Breath", description: "Lança uma bola de fogo da boca." },
      { name: "Claw Attack", description: "Ataca o inimigo com suas garras afiadas." }
    ]
  },
  {
    id: 3, name: "Greymon", image: IMG("Greymon"),
    description: "Evolução de Agumon. Um dinossauro de chifres poderosos, forte e bastante agressivo em batalha.",
    type: "Dinosaur", fields: ["Nature Spirits", "Dragon's Roar"], level: "Champion",
    skills: [
      { name: "Nova Blast", description: "Cospe uma enorme bola de fogo." },
      { name: "Horn Impulse", description: "Investe com os chifres contra o adversário." }
    ]
  },
  {
    id: 4, name: "Gabumon", image: IMG("Gabumon"),
    description: "Um Digimon tímido que usa a pele de um Garurumon. Muito leal ao seu parceiro.",
    type: "Reptile", fields: ["Nature Spirits", "Metal Empire"], level: "Rookie",
    skills: [
      { name: "Blue Blaster", description: "Sopra uma chama azul gelada." },
      { name: "Horn Attack", description: "Golpeia o inimigo com o chifre." }
    ]
  },
  {
    id: 5, name: "Garurumon", image: IMG("Garurumon"),
    description: "Um lobo azul veloz e feroz. Corre pelos campos de gelo e protege o seu grupo.",
    type: "Beast", fields: ["Nature Spirits", "Metal Empire"], level: "Champion",
    skills: [
      { name: "Howling Blaster", description: "Lança chamas azuis em alta velocidade." },
      { name: "Fox Fire", description: "Cria chamas azuis ao redor do corpo." }
    ]
  },
  {
    id: 6, name: "Patamon", image: IMG("Patamon"),
    description: "Pequeno Digimon voador com orelhas em forma de asas. Parece frágil, mas tem muita determinação.",
    type: "Mammal", fields: ["Nature Spirits", "Wind Guardians"], level: "Rookie",
    skills: [
      { name: "Boom Bubble", description: "Dispara uma bolha de ar comprimido." },
      { name: "Air Shot", description: "Atira rajadas de ar em quem o ameaça." }
    ]
  },
  {
    id: 7, name: "Angemon", image: IMG("Angemon"),
    description: "Um anjo guerreiro que luta pela justiça. Carrega um cajado sagrado e usa o poder da luz.",
    type: "Angel", fields: ["Nature Spirits", "Wind Guardians"], level: "Champion",
    skills: [
      { name: "Hand of Fate", description: "Concentra energia sagrada no punho e ataca." },
      { name: "Heaven's Gate", description: "Abre um portal que leva o mal embora." }
    ]
  },
  {
    id: 8, name: "WarGreymon", image: IMG("WarGreymon"),
    description: "Um guerreiro dracônico com armadura de Chrome Digizoid. É extremamente poderoso e protege os Digimons.",
    type: "Dragon Man", fields: ["Dragon's Roar", "Virus Busters"], level: "Mega",
    skills: [
      { name: "Terra Force", description: "Reúne energia do ambiente em uma esfera gigante." },
      { name: "Great Tornado", description: "Gira em alta velocidade e investe contra o inimigo." }
    ]
  }
];