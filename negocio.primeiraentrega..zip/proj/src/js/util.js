// Funções compartilhadas pelas duas páginas (evita repetir código)

// Cria um elemento com classe e texto
function criar(tag, classe, texto) {
  const el = document.createElement(tag);
  if (classe) el.className = classe;
  if (texto !== undefined) el.textContent = texto;
  return el;
}

function formatarId(id) {
  return "#" + String(id).padStart(3, "0");
}

// Imagem de reserva (SVG com as iniciais) usada se a URL falhar
function imagemReserva(nome) {
  const iniciais = nome.slice(0, 2).toUpperCase();
  const svg =
    '<svg xmlns="http://www.w3.org/2000/svg" width="200" height="200">' +
    '<rect width="200" height="200" fill="#0b2a1c"/>' +
    '<text x="100" y="118" font-family="monospace" font-size="64" fill="#2fbf71" text-anchor="middle">' +
    iniciais + "</text></svg>";
  return "data:image/svg+xml;utf8," + encodeURIComponent(svg);
}

// Cria a <img> de um Digimon já com alt e reserva
function criarImagem(digimon, classe) {
  const img = criar("img", classe);
  img.src = digimon.image;
  img.alt = "Imagem do Digimon " + digimon.name;
  img.loading = "lazy";
  img.onerror = () => { img.onerror = null; img.src = imagemReserva(digimon.name); };
  return img;
}