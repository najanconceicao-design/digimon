// ===== Página inicial: grade de cartões + busca =====
const grade = document.getElementById("grade");
const vazio = document.getElementById("vazio");
const formBusca = document.getElementById("form-busca");
const buscaInput = document.getElementById("busca-input");

// Um cartão da grade (link para a página de detalhe)
function criarCartao(d) {
  const link = criar("a", "card");
  link.href = "digimon.html?id=" + d.id;
  link.append(
    criarImagem(d, "card__imagem"),
    criar("h2", "card__nome", d.name),
    criar("p", "card__nivel", "Nível: " + d.level)
  );
  return link;
}

function mostrarLista(lista) {
  grade.replaceChildren(...lista.map(criarCartao));
  vazio.hidden = lista.length > 0;
}

// Filtra por nome, nível ou ID enquanto a pessoa digita
function filtrar() {
  const termo = buscaInput.value.trim().toLowerCase().replace("#", "");
  const resultado = DIGIMONS.filter(
    (d) =>
      d.name.toLowerCase().includes(termo) ||
      d.level.toLowerCase().includes(termo) ||
      String(d.id) === termo
  );
  mostrarLista(resultado);
}

buscaInput.addEventListener("input", filtrar);
formBusca.addEventListener("submit", (e) => { e.preventDefault(); filtrar(); });

mostrarLista(DIGIMONS);