
const API_URL = "https://digi-api.com/api/v1/digimon";
const TEMPO_LIMITE_MS = 10000;
 
const form = document.getElementById("form-busca");
const campoBusca = document.getElementById("campo-busca");
const boxCarregando = document.getElementById("carregando");
const boxErro = document.getElementById("erro");
const cartao = document.getElementById("cartao");
const btnAnterior = document.getElementById("btn-anterior");
const btnProximo = document.getElementById("btn-proximo");
const botoes = document.querySelectorAll("button");
 
let idAtual = null;
 
/* ---------- Função de consulta ---------- */
// Recebe um nome ou um ID e devolve o objeto do Digimon.
// Lança um Error com mensagem compreensível quando algo dá errado.
async function consultarDigimon(termo) {
  const valor = String(termo).trim();
  if (!valor) {
    throw new Error("Digite o nome ou o número de um Digimon.");
  }
 
  const controlador = new AbortController();
  const timer = setTimeout(() => controlador.abort(), TEMPO_LIMITE_MS);
 
  let resposta;
  try {
    resposta = await fetch(`${API_URL}/${encodeURIComponent(valor)}`, {
      signal: controlador.signal,
    });
  } catch (e) {
    if (e.name === "AbortError") {
      throw new Error("A consulta demorou demais. Tente novamente em instantes.");
    }
    throw new Error("Não foi possível conectar à API. Verifique sua internet e tente de novo.");
  } finally {
    clearTimeout(timer);
  }
 
  if (!resposta.ok) {
    if (resposta.status === 404) {
      throw new Error(`Digimon "${valor}" não encontrado. Confira o nome ou o número.`);
    }
    if (resposta.status >= 500) {
      throw new Error("A API está com problemas no momento. Tente novamente mais tarde.");
    }
    throw new Error(`A consulta falhou (código ${resposta.status}).`);
  }
 
  let dados;
  try {
    dados = await resposta.json();
  } catch (e) {
    throw new Error("A API respondeu em um formato inesperado.");
  }
 
  if (!dados || typeof dados !== "object" || dados.id == null || !dados.name) {
    throw new Error("A resposta da API veio incompleta.");
  }
  return dados;
}
 
/* ---------- Processamento da resposta ---------- */
function listarTexto(lista, campo) {
  if (!Array.isArray(lista) || lista.length === 0) return "—";
  const itens = lista.map((item) => item && item[campo]).filter(Boolean);
  return itens.length ? itens.join(", ") : "—";
}
 
function escolherDescricao(descricoes) {
  if (!Array.isArray(descricoes) || descricoes.length === 0) {
    return "Sem descrição disponível.";
  }
  const preferida =
    descricoes.find((d) => d && d.language === "en_us" && d.description) ||
    descricoes.find((d) => d && d.description);
  return preferida ? preferida.description : "Sem descrição disponível.";
}
 
function mostrarDigimon(d) {
  idAtual = d.id;
 
  document.getElementById("digi-id").textContent = d.id;
  document.getElementById("digi-nome").textContent = d.name;
  document.getElementById("digi-descricao").textContent = escolherDescricao(d.descriptions);
  document.getElementById("digi-nivel").textContent = listarTexto(d.levels, "level");
  document.getElementById("digi-tipo").textContent = listarTexto(d.types, "type");
  document.getElementById("digi-areas").textContent = listarTexto(d.fields, "field");
  document.getElementById("digi-habilidades").textContent = listarTexto(d.skills, "skill");
 
  const img = document.getElementById("digi-imagem");
  const href = Array.isArray(d.images) && d.images[0] ? d.images[0].href : "";
  if (href) {
    img.src = href;
    img.alt = `Imagem do Digimon ${d.name}`;
    img.hidden = false;
  } else {
    img.removeAttribute("src");
    img.alt = "";
    img.hidden = true;
  }
 
  cartao.hidden = false;
}
 
/* ---------- Estados da interface ---------- */
function mostrarCarregando(ativo) {
  boxCarregando.hidden = !ativo;
  botoes.forEach((b) => (b.disabled = ativo));
}
 
function mostrarErro(mensagem) {
  boxErro.textContent = mensagem;
  boxErro.hidden = false;
}
 
function limparErro() {
  boxErro.textContent = "";
  boxErro.hidden = true;
}
 
/* ---------- Fluxo principal ---------- */
async function buscar(termo) {
  limparErro();
  cartao.hidden = true;
  mostrarCarregando(true);
 
  try {
    const digimon = await consultarDigimon(termo);
    mostrarDigimon(digimon);
  } catch (e) {
    mostrarErro(e.message || "Ocorreu um erro inesperado.");
  } finally {
    // Sempre executa: o indicador some mesmo se a consulta falhar
    mostrarCarregando(false);
  }
}
 
form.addEventListener("submit", (evento) => {
  evento.preventDefault();
  buscar(campoBusca.value);
});
 
btnProximo.addEventListener("click", () => {
  if (idAtual != null) buscar(idAtual + 1);
});
 
btnAnterior.addEventListener("click", () => {
  if (idAtual != null && idAtual > 1) buscar(idAtual - 1);
});
 
// Carrega um Digimon inicial ao abrir a página
buscar(1);
 