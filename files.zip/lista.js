// ===== Configuração =====
const API_URL = "https://digi-api.com/api/v1/digimon";
const TAMANHO_PAGINA = 100;

// ===== Elementos da página =====
const status = document.getElementById("status");
const lista = document.getElementById("lista");
const botoesOrdem = document.querySelectorAll("#opcoes-ordem button");

// ===== Estado =====
let digimons = [];          // todos os Digimons carregados
let ordemAtual = "az";      // ordem inicial: alfabética pelo nome

// ===== Formas de ordenar =====
const comparar = (a, b) => a.localeCompare(b, "en", { sensitivity: "base" });

const ordens = {
  "az":      (a, b) => comparar(a.name, b.name),
  "za":      (a, b) => comparar(b.name, a.name),
  "id-asc":  (a, b) => a.id - b.id,
  "id-desc": (a, b) => b.id - a.id,
  // em caso de empate no tamanho, desempata pelo nome
  "curto":   (a, b) => a.name.length - b.name.length || comparar(a.name, b.name),
  "longo":   (a, b) => b.name.length - a.name.length || comparar(a.name, b.name),
};

// ===== Mensagens =====
function mostrarStatus(texto, ehErro = false) {
  status.textContent = texto;
  status.classList.toggle("erro", ehErro);
}

// ===== Desenhar a lista =====
function desenharLista() {
  const ordenados = [...digimons].sort(ordens[ordemAtual]);
  const fragmento = document.createDocumentFragment();

  ordenados.forEach((d) => {
    const li = document.createElement("li");
    const nome = document.createElement("span");
    nome.textContent = d.name;
    const num = document.createElement("span");
    num.className = "num";
    num.textContent = "#" + d.id;
    li.append(nome, num);
    fragmento.appendChild(li);
  });

  lista.replaceChildren(fragmento);

  botoesOrdem.forEach((b) => {
    b.setAttribute("aria-pressed", String(b.dataset.ordem === ordemAtual));
  });
}

// ===== Requisições =====
async function pedirJson(url) {
  const resposta = await fetch(url);
  if (!resposta.ok) throw new Error("Erro HTTP " + resposta.status);
  return resposta.json();
}

function urlPagina(pagina) {
  return API_URL + "?pageSize=" + TAMANHO_PAGINA + "&page=" + pagina;
}

// Carrega todas as páginas da API e junta tudo numa lista só
async function carregarTodos() {
  const primeira = await pedirJson(API_URL + "?pageSize=" + TAMANHO_PAGINA);
  const info = primeira.pageable || {};
  const totalPaginas = info.totalPages || 1;
  const paginaInicial = info.currentPage || 0;

  const pedidos = [];
  for (let p = 0; p < totalPaginas; p++) {
    if (p !== paginaInicial) pedidos.push(pedirJson(urlPagina(p)));
  }
  const outras = await Promise.all(pedidos);

  // Map por ID evita repetidos
  const porId = new Map();
  [primeira, ...outras].forEach((resp) => {
    (resp.content || []).forEach((item) => porId.set(item.id, item));
  });
  return [...porId.values()];
}

// ===== Eventos =====
botoesOrdem.forEach((botao) => {
  botao.addEventListener("click", () => {
    ordemAtual = botao.dataset.ordem;
    desenharLista();
  });
});

// ===== Início =====
(async function iniciar() {
  mostrarStatus("Carregando lista de Digimons...");
  botoesOrdem.forEach((b) => (b.disabled = true));
  try {
    digimons = await carregarTodos();
    if (digimons.length === 0) {
      mostrarStatus("Nenhum Digimon foi retornado pela API.", true);
      return;
    }
    desenharLista();
    mostrarStatus(digimons.length + " Digimons carregados.");
    botoesOrdem.forEach((b) => (b.disabled = false));
  } catch (erro) {
    mostrarStatus("Não foi possível carregar a lista. Verifique sua conexão e recarregue a página.", true);
    console.error(erro);
  }
})();
